import PMKSystemConfiguration
import XCTest

class PMKSCTestCase: XCTestCase {
    func test() {
        // just verify everything links etc.
        SCNetworkReachability()
    }
}
