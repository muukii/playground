import PMKCoreBluetooth
import CoreBluetooth
import XCTest

class PMKCBTestCase: XCTestCase {
    func test() {
        // just test linking etc.
        CBCentralManager.state()
    }
}
