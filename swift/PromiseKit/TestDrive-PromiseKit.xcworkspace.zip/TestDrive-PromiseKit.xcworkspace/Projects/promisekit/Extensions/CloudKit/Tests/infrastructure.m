@import CloudKit;

CKUserIdentity *PMKDiscoveredUserInfo() {
    return [CKUserIdentity alloc];
}
