@class CKUserIdentity;
extern CKUserIdentity *PMKDiscoveredUserInfo();
