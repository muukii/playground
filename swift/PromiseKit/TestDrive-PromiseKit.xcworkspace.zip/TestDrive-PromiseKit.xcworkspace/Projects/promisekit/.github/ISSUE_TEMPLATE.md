If your issue is a Swift compile issue then read our Troubleshooting guide first:

    https://github.com/mxcl/PromiseKit/blob/master/Documentation/Troubleshooting.md

---    

In your ticket PLEASE specify the PromiseKit version (major version is enough).

---

Please format your code in triple backticks and ensure readable indentation:

     https://help.github.com/articles/creating-and-highlighting-code-blocks/
