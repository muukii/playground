//
//  RealmPartialUpdate.h
//  RealmPartialUpdate
//
//  Created by muukii on 2019/10/23.
//  Copyright © 2019 muukii. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for RealmPartialUpdate.
FOUNDATION_EXPORT double RealmPartialUpdateVersionNumber;

//! Project version string for RealmPartialUpdate.
FOUNDATION_EXPORT const unsigned char RealmPartialUpdateVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <RealmPartialUpdate/PublicHeader.h>


